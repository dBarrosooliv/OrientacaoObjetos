/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.OpDivisao;
import Model.OpMat;
import Model.OpMult;
import Model.OpSoma;
import Model.OpSub;
import View.Janela;

/**
 *
 * @author unifdoliveira
 */
public class Controlador {
    
    private Janela janela;
    private OpMat calcular;
    private String n1;
    private String n2;
    
    public Controlador(Janela janela){
        this.janela = janela;
    }
    
    public void dgtZero(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "0");
    }
    
    public void dgtUm(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "1");
    }
    
    public void dgtDois(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "2");
    }

    public void dgtTres(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "3");
    }
    
    public void dgtQuatro(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "4");
    }

    public void dgtCinco(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "5");
    }

    public void dgtSeis(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "6");
    }
    
    public void dgtSete(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "7");
    }
 
    public void dgtOito(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "8");
    }
 
    public void dgtNove(){
        String texto = janela.getDisplayCalculadora().getText();
        janela.getDisplayCalculadora().setText(texto + "9");
    }
    
    public void OpSoma(){
        n1 = janela.getDisplayCalculadora().getText();
        calcular = new OpSoma();
        janela.getDisplayCalculadora().setText("");
    }
    
    public void OpSub(){
        n1 = janela.getDisplayCalculadora().getText();
        calcular = new OpSub();
        janela.getDisplayCalculadora().setText("");
    }
    
    public void OpMult(){
        n1 = janela.getDisplayCalculadora().getText();
        calcular = new OpMult();
        janela.getDisplayCalculadora().setText("");
    }    
    
    public void OpDiv(){
        n1 = janela.getDisplayCalculadora().getText();
        calcular = new OpDivisao();
        janela.getDisplayCalculadora().setText("");
    }    
    
    public void Clear(){
        janela.getDisplayCalculadora().setText("");
    }
    
    public void Resultado(){
        
        n2 = janela.getDisplayCalculadora().getText();  
        double resposta = this.calcular.calcular(Double.parseDouble(n1), Double.parseDouble(n2));
        janela.getDisplayCalculadora().setText(String.valueOf(resposta));
    }
}
