/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unifdoliveira
 */
public class Data {

    private int dia;
    private int diaJuliano;
    private int mes;
    private int ano;
    private String mesString;
    
    //CONSTRUTOR VAZIO
    
    public Data(){
        this.dia = 0;
        this.diaJuliano = 0;
        this.mes = 0;
        this.ano = 0;
        this.mesString = "vazio";
    }
    //GREGORIANA1
    public Data(int dia, int mes, int ano){
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }
    public void ExibeGreg1(){
        System.out.printf("%d/%d/%d\n", mes, dia, ano);
    }
    
    //GREGORIANA2
    public Data(int dia, String mesString, int ano){
        this.dia = dia;
        this.mesString = mesString;
        this.ano = ano;
    }
    public void ExibeGreg2(){
        System.out.println( mesString + " " + dia + " " + ano + "\n");
    }
    
    //JULIANO -> Greg
    public Data(int diaJuliano, int ano){
        this.ano = ano;
        if (diaJuliano <= 31) {
            this.mes = 1;
            this.dia = diaJuliano;
        } else if (diaJuliano <= 59) {
            this.mes = 2;
            this.dia = diaJuliano - 31;
        } else if (diaJuliano <= 90) {
            this.mes = 3;
            this.dia = diaJuliano - 59;
        } else if (diaJuliano <= 120) {
            this.mes = 4;
            this.dia = diaJuliano - 90;
        } else if (diaJuliano <= 151) {
            this.mes = 5;
            this.dia = diaJuliano - 120;
        } else if (diaJuliano <= 181) {
            this.mes = 6;
            this.dia = diaJuliano - 151;
        } else if (diaJuliano <= 212) {
            this.mes = 7;
            this.dia = diaJuliano - 181;
        } else if (diaJuliano <= 243) {
            this.mes = 8;
            this.dia = diaJuliano - 212;
        } else if (diaJuliano <= 273) {
            this.mes = 9;
            this.dia = diaJuliano - 243;
        } else if (diaJuliano <= 304) {
            this.mes = 10;
            this.dia = diaJuliano - 273;
        } else if (diaJuliano <= 334) {
            this.mes = 11;
            this.dia = diaJuliano - 304;
        } else {
            this.mes = 12;
            this.dia = diaJuliano - 334;
        }
    }
    
    public void AuxJulinao2_3(int dia, int mes, int ano) {
        this.ano = ano;
        if (mes == 1) {
            this.diaJuliano = dia;
        } else if (mes == 2) {
            this.diaJuliano = 31 + dia;
        } else if (mes == 3) {
            this.diaJuliano = 59 + dia;
        } else if (mes == 4) {
            this.diaJuliano = 90 + dia;
        } else if (mes == 5) {
            this.diaJuliano = 120 + dia;
        } else if (mes == 6) {
            this.diaJuliano = 151 + dia;
        } else if (mes == 7) {
            this.diaJuliano = 181 + dia;
        } else if (mes == 8) {
            this.diaJuliano = 212 + dia;
        } else if (mes == 9) {
            this.diaJuliano = 243 + dia;
        } else if (mes == 10) {
            this.diaJuliano = 273 + dia;
        } else if (mes == 11) {
            this.diaJuliano = 304 + dia;
        } else if (mes == 12) {
            this.diaJuliano = 334 + dia;
        }
     }
    public void ExibeJul(){
        System.out.println( diaJuliano + "/" + ano + "\n");
    }
    
    //MÉTODOS AUXILIARES
    //====> STRING --> NUM

    public void MesNum(){
        if(mesString.equals("Janeiro")){
            this.mes = 1;
        }
        else if(mesString.equals("Fevereiro")){
            this.mes = 2;
        }
        else if(mesString.equals("Março")){
            this.mes = 3;
        }
        else if(mesString.equals("Abril")){
            this.mes = 4;
        }
        else if(mesString.equals("Maio")){
            this.mes = 5;
        }
        else if(mesString.equals("Junho")){
            this.mes = 6;
        }
        else if(mesString.equals("Julho")){
            this.mes = 7;
        }
        else if(mesString.equals("Agosto")){
            this.mes = 8;
        }
        else if(mesString.equals("Setembro")){
            this.mes = 9;
        }
        else if(mesString.equals("Outubro")){
            this.mes = 10;
        }
        else if(mesString.equals("Novembro")){
            this.mes = 11;
        }
        else if(mesString.equals("Dezembro")){
            this.mes = 12;
        }
    }
    
    //====> NUM --> MES
    
    public void NumMes(){
        if(mes == 1){
            this.mesString = "Janeiro";
        }
        else if(mes == 2){
            this.mesString = "Fevereiro";
        }
        else if(mes == 3){
            this.mesString = "Março";
        }
        else if(mes == 4){
            this.mesString = "Abril";
        }
        else if(mes == 5){
            this.mesString = "Maio";
        }
        else if(mes == 6){
            this.mesString = "Junho";
        }
        else if(mes == 7){
            this.mesString = "Julho";
        }
        else if(mes == 8){
            this.mesString = "Agosto";
        }
        else if(mes == 9){
            this.mesString = "Setembro";
        }
        else if(mes == 10){
            this.mesString = "Outubro";
        }
        else if(mes == 11){
            this.mesString = "Novembro";
        }
        else if(mes == 12){
            this.mesString = "Dezembro";
        }
    }
   
    //GETS
    public int getDia(){
        return dia;
    }
    public int getMes(){
        return mes;
    }
    public String getMesString(){
        return mesString;
    }
    public int getAno(){
        return ano;
    }
    //SETS
    public void setDia(int dia){
        this.dia = dia;
    }
    public void setMes(int mes){
        this.mes = mes;
    }
    public void setMesString(String mesString){
        this.mesString = mesString;
    }
    public void setAno(int ano){
        this.ano = ano;
    }
    
    public void imprimir(){
        System.out.printf("%d/%d/%d", mes, dia, ano);
    }
}

