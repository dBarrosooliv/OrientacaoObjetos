
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unifdoliveira
 */
public class Main {
    public static void main (String[] args){
        int loop = 1; 

        Scanner input = new Scanner(System.in);
        while(loop ==1){
            
            System.out.println("::: DATA APRIMORADA :::\n");
            System.out.println("Como você deseja informar* a data?\n");
            System.out.println("1. MM/DD/YYYY\n");
            System.out.println("2. Maio 31, 2025\n");
            System.out.println("3. DDD/YYYY (Juliano)\n");
            System.out.println("4. Sair\n");
            int decisao1 = input.nextInt();
                        
            if (decisao1 == 4){
                loop = 99;
                break;
            }
            
            System.out.println("Como você deseja exibir* a data?\n");
            System.out.println("1. MM/DD/YYYY\n");
            System.out.println("2. Maio 31, 2025\n");
            System.out.println("3. DDD/YYYY (Juliano)\n");
            
            int decisao2 = input.nextInt();

            if(decisao1 == 1 && decisao2 == 1){
                System.out.println("Informe o dia: ");
                int diag1 = input.nextInt();
                System.out.println("Informe o mes: ");
                int mesg1 = input.nextInt();
                System.out.println("Informe o ano: ");
                int anog1 = input.nextInt();
                Data dg1 = new Data(diag1,mesg1,anog1);
                dg1.ExibeGreg1();
            }
            
            else if(decisao1 == 1 && decisao2 == 2){
                System.out.println("Informe o dia: ");
                int diag1 = input.nextInt();
                System.out.println("Informe o mes: ");
                int mesg1 = input.nextInt();
                System.out.println("Informe o ano: ");
                int anog1 = input.nextInt();
                Data dg2 = new Data(diag1,mesg1,anog1);
                dg2.NumMes();
                dg2.ExibeGreg2();
            }
            
            else if(decisao1 == 1 && decisao2 == 3){
                System.out.println("Informe o dia: ");
                int diag1 = input.nextInt();
                System.out.println("Informe o mes: ");
                int mesg1 = input.nextInt();
                System.out.println("Informe o ano: ");
                int anog1 = input.nextInt();
                Data dj = new Data(diag1,mesg1,anog1);
                dj.AuxJulinao2_3(diag1, mesg1, anog1);
                dj.ExibeJul();
            }
            
            if(decisao1 == 2 && decisao2 == 1){
                System.out.println("Informe o dia: ");
                int diag2 = input.nextInt();
                System.out.println("Informe o mes (por extenso): ");
                String mesg2 = input.next();
                System.out.println("Informe o ano: ");
                int anog2 = input.nextInt();
                Data dg2 = new Data(diag2,mesg2,anog2);
                dg2.MesNum();
                dg2.ExibeGreg1();
            }
            if(decisao1 == 2 && decisao2 == 2){
                System.out.println("Informe o dia: ");
                int diag2 = input.nextInt();
                System.out.println("Informe o mes (por extenso): ");
                String mesg2 = input.next();
                System.out.println("Informe o ano: ");
                int anog2 = input.nextInt();
                Data dg2 = new Data(diag2,mesg2,anog2);
                dg2.ExibeGreg2();
            }
            if(decisao1 == 2 && decisao2 == 3){
                System.out.println("Informe o dia: ");
                int diag2 = input.nextInt();
                System.out.println("Informe o mes (por extenso): ");
                String mesg2 = input.next();
                System.out.println("Informe o ano: ");
                int anog2 = input.nextInt();
                Data dj = new Data(diag2,mesg2,anog2);
                dj.MesNum();
                int pegarmes = dj.getMes();
                dj.AuxJulinao2_3(diag2, pegarmes, anog2);
                dj.ExibeJul();
            }
                        
            if(decisao1 == 3 && decisao2 == 1){
                System.out.println("Informe o dia: ");
                int dia = input.nextInt();
                System.out.println("Informe o ano: ");
                int ano = input.nextInt();
                Data dj = new Data(dia,ano);
                
                int pegardia = dj.getDia();
                int pegarmes = dj.getMes();
                Data diafinal = new Data(pegardia,pegarmes,ano);
                diafinal.ExibeGreg1();
            }
            else if( decisao1 == 3 && decisao2 == 2){
                System.out.println("Informe o dia: ");
                int dia = input.nextInt();
                System.out.println("Informe o ano: ");
                int ano = input.nextInt();
                Data dj = new Data(dia,ano);
                dj.NumMes();
                
                int pegardia = dj.getDia();
                String pegarmes = dj.getMesString();
                Data diafinal = new Data(pegardia,pegarmes,ano);
                diafinal.ExibeGreg2();
            }
            else if( decisao1 == 3 && decisao2 == 3){
                System.out.println("Informe o dia: ");
                int dia = input.nextInt();
                System.out.println("Informe o ano: ");
                int ano = input.nextInt();
                System.out.println(dia+"/"+ano);
            }
            
            
            
        }
        System.out.println("::: FIM :::\n");
    }
    
}
