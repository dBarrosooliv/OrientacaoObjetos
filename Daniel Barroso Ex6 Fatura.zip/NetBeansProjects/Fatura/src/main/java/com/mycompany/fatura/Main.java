/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fatura;

import java.util.Scanner;

/**
 *
 * @author unifdoliveira
 */
public class Main {
    public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);
        
        System.out.println(":::: CALCULAR VALOR DA FATURA ::::\n");
        Invoice pd1 = new Invoice();
        Invoice pd2 = new Invoice();
        
        System.out.println("==> PRODUTO UM \n");
        System.out.println("Digite o valor do identificador: ");
        String id = input.next();
        pd1.setId(id);
        
        System.out.println("Digite uma breve descrição: ");
        String descricao = input.next();
        pd1.setDesc(descricao);
        
        System.out.println("Digite a quantidade do produto: ");
        int quantidade = input.nextInt();
        pd1.setQuant(quantidade);
        
        System.out.println("Digite o preço do produto: ");
        double preco = input.nextDouble();
        pd1.setPreco(preco);
        
        System.out.println("==> PRODUTO DOIS \n");
        System.out.println("Digite o valor do identificador: ");
        String id2 = input.next();
        pd2.setId(id2);
        
        System.out.println("Digite uma breve descrição: ");
        String descricao2 = input.next();
        pd2.setDesc(descricao2);
        
        System.out.println("Digite a quantidade do produto: ");
        int quantidade2 = input.nextInt();
        pd2.setQuant(quantidade2);
        
        System.out.println("Digite o preço do produto: ");
        double preco2 = input.nextDouble();
        pd2.setPreco(preco2);
        
        double quantDouble = pd1.getQuant();
        double quantDouble2 = pd2.getQuant();
        
        System.out.println(":::: RESULTADO DO CALCULO ::::\n");
        System.out.println("==> PRODUTO UM \n");
        System.out.println("ID do produto: " + pd1.getId());
        System.out.println("Descrição: " + pd1.getDesc());
        System.out.printf("Quantidade: %.2f\n", quantDouble);
        System.out.printf("Preco: %.2f\n", pd1.getPreco());
        System.out.println("==> FATURA: \n" + pd1.getInvoiceAmount());
        System.out.println("==> PRODUTO DOIS \n");
        System.out.println("ID do produto: " + pd2.getId());
        System.out.println("Descrição: " + pd2.getDesc());
        System.out.printf("Quantidade: %.2f\n", quantDouble2);
        System.out.printf("Preco: %.2f\n", pd2.getPreco());
        System.out.println("==> FATURA: " + pd2.getInvoiceAmount());
        
    }
}
