/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fatura;

/**
 *
 * @author unifdoliveira
 */
public class Invoice {
    
    private String id;
    private String descricao;
    private int quantidade;
    private double preco;
    
    public String getId(){
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
            
    public String getDesc(){
        return descricao;
    }
    
    public void setDesc(String descricao) {
        this.descricao = descricao;
    }
    
    public int getQuant(){
        return quantidade;
    }
    
    public void setQuant(int quantidade) {
        if(quantidade > 0){
            this.quantidade = quantidade;
        }
        else{
            this.quantidade = 0;
        }
    }
    
    public double getPreco(){
        return preco;
    }
    
    public void setPreco(double preco) {
        if (preco > 0){
            this.preco = preco;
        }
        else{
            this.quantidade = 0;
        }
    }
    
    public double getInvoiceAmount(){
        
        double vlr_fatura = quantidade*preco;
        return vlr_fatura;
    }
    
}
