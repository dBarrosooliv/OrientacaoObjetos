/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg5;

import java.util.Scanner;

/**
 *
 * @author unifhburielo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        System.out.println("::: PROGRAMA :::\n");
        
        int infinito =1;
        int homens = 0;
        int mulheres = 0;
        int mulheres600 = 0;
        int acc_idade = 0;
        double acumulador_sal =0;
        
        while( infinito==1){
            
            System.out.println("Digite sua idade: ");
            int idade = input.nextInt();
            
            if(idade<0){
                infinito = 99;
                break;
            }
            
            System.out.println("Digite seu salário: ");
            double salario = input.nextDouble();
            
            acc_idade += idade;
            
            System.out.println("Digite seu sexo: (1- Homem 0- Mulher)");
            int sexo = input.nextInt();
            
            if (sexo==1){
                homens++;
                acumulador_sal += salario;
            }
            if (sexo==0 && salario<600){
                mulheres++;
                mulheres600++;
            }
            

            
        }
                    double mediaIdade = acc_idade/(homens+mulheres);
            double mediaSalHomens = acumulador_sal/homens;
        System.out.printf("Idade média do grupo: %.2f\n", mediaIdade);
        System.out.printf("Média Salarial dos Homens: %.2f\n", mediaSalHomens);
        System.out.printf("Mulheres que recebem menos que 600: %d\n", mulheres600);
    }
    
}
