/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2;

import java.util.Scanner;

/**
 *
 * @author unifhburielo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        for (int i =1; i<=50;i++){
            System.out.printf("%d\n",i );
        }
        for (int j =52;j<=100; j+=2){
            System.out.printf("%d\n", j);
        }
      
    
    }
    
}
