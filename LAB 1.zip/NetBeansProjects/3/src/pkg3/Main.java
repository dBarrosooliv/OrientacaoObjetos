/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg3;

import java.util.Scanner;

/**
 *
 * @author unifhburielo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        System.out.println("Digite um numero n");
        double num = input.nextDouble();
        
        System.out.println("S: ");
        for(int i = 1; i<=num; i++){ // 1 + 2 3 4 5 6 7 8
            if(i==num){
                System.out.printf("1/%d ", i);
            }
            else{
            System.out.printf("1/%d + ", i);
            }
        }
    }
    
}
