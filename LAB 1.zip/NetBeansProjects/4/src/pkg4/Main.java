/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg4;

import java.util.Scanner;

/**
 *
 * @author unifhburielo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int aprovados = 0;
        double acumulador = 0;
        for(int i=0; i <80; i++){
            System.out.println("Digite sua nota: ");
            double nota = input.nextDouble();
            acumulador += nota;
            if(nota>=6 && nota<=10){
                aprovados++;
            }
        }
        
        double media = acumulador/80;

        System.out.printf("Alunos aprovados: %d\n", aprovados);
        System.out.printf("Média da Turma: %.2f\n", media);
    }
    
}
