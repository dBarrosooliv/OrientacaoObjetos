/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matrix;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author unifdoliveira
 */
public class Matrix {
    public static void main(String[] args){
    
    Random random = new Random();
    Scanner input = new Scanner(System.in);
    ArrayList<Agente> agentes = new ArrayList<>();
    
    System.out.println("::: MATRIX :::");
    while(1==1){
        System.out.println("++ Cadastre cidadaos");
        System.out.println("1. Empresario");
        System.out.println("2. Professor");
        System.out.println("3. Advogado");
        System.out.println("4. Apresentar");
        System.out.println("0. Sair");
        System.out.println("Escolha: ");
        int escolha = input.nextInt();
        
        if(escolha == 0){
            System.out.println("::: FIM :::");
            break;
        }
        else if (escolha == 1){
            System.out.println("Digite seu nome: ");
            String nome = input.next();
            System.out.println("Digite sua profissao: ");
            String profissao = input.next();
            System.out.println("Digite sua empresa: ");
            String empresa = input.next();
            
            Empresario emp = new Empresario(nome,profissao,empresa);
            agentes.add(emp);
        }
        else if (escolha == 2){
            System.out.println("Digite seu nome: ");
            String nome = input.next();
            System.out.println("Digite sua profissao: ");
            String profissao = input.next();
            System.out.println("Digite sua escola: ");
            String escola = input.next();
            
            Professor prof = new Professor(nome,profissao,escola);
            agentes.add(prof);
        }
        else if (escolha == 3){
            System.out.println("Digite seu nome: ");
            String nome = input.next();
            System.out.println("Digite sua profissao: ");
            String profissao = input.next();
            System.out.println("Digite seu codigo OAB: ");
            String oab = input.next();
            
            Advogado adv = new Advogado(nome,profissao,oab);
            agentes.add(adv);
        }
        else if (escolha == 4){
            //Para fazer a ativação de um agente, escolhi sortear um valor dentro do array e fazer sua ativação,
            int tamanhoArray = agentes.size();
            if (tamanhoArray> 0){
                
                int valorAleatorio = random.nextInt(tamanhoArray);

                for(int i = 0; i<tamanhoArray; i++){
                    if (i == valorAleatorio){
                        agentes.get(valorAleatorio).ativaAgente();
                    }
                }
                for(Agente ag: agentes){
                    ag.apresentacao();
                }
            }
            else{
                System.out.println("Cadastre pessoas!");
            }
                
        }
    
    }
    
    }
}
