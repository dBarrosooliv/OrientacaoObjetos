/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matrix;

/**
 *
 * @author unifdoliveira
 */
public class Empresario extends Agente {
    
    private String nome; 
    private boolean modo_agente = false;
    private String profissao;
    private String empresa;

    public Empresario(String nome, String profissao, String empresa) {
        this.nome = nome;
        this.profissao = profissao;
        this.empresa = empresa;
    }
    
    @Override
    void apresentacao() {
        if ( modo_agente == false ){
            System.out.println("==> Nome: " + this.nome);
            System.out.println("Profissao: " + this.profissao);
            System.out.println("Empresa: " + this.empresa);
        }
        else{
            System.out.println(">>> AGENTE " + this.nome);
        }
    }

    @Override
    void ativaAgente() {
        this.modo_agente = true;
    }
    
}
