/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matrix;

/**
 *
 * @author unifdoliveira
 */
public class Professor extends Agente{
    
    private String nome; 
    private boolean modo_agente = false;
    private String profissao;
    private String escola;

    public Professor(String nome, String profissao, String escola) {
        this.nome = nome;
        this.profissao = profissao;
        this.escola = escola;
    }
    
    @Override
    void apresentacao() {
        if ( modo_agente == false ){
            System.out.println("==> Nome: " + this.nome);
            System.out.println("Profissao: " + this.profissao);
            System.out.println("Escola: " + this.escola);
        }
        else{
            System.out.println(">>> AGENTE " + this.nome);
        }
        
    }

    @Override
    void ativaAgente() {
        this.modo_agente = true;
    }
    
}
