/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matrix;

/**
 *
 * @author unifdoliveira
 */
public class Advogado extends Agente {
        
    private String nome; 
    private boolean modo_agente = false;
    private String profissao;
    private String OAB;

    public Advogado(String nome, String profissao, String OAB) {
        this.nome = nome;
        this.profissao = profissao;
        this.OAB = OAB;
    }
    
    @Override
    void apresentacao() {
        if ( modo_agente == false ){
            System.out.println("==> Nome: " + this.nome);
            System.out.println("Profissao: " + this.profissao);
            System.out.println("OAB: " + this.OAB);
        }
        else{
            System.out.println(">>> AGENTE " + this.nome);
        }
    }

    @Override
    void ativaAgente() {
        this.modo_agente = true;
    }
    
}
