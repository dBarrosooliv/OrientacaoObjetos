/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agenda;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifdoliveira
 */
public class Main {
    public static void main (String[] args){
        
        ArrayList<Agenda> pessoas = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        String entrada = "vazio";
        
        while(!entrada.equals("q")){
            
            System.out.println(":::: AGENDA DE CONTATOS ::::");
            System.out.println("=> Escolha uma das opcoes");
            System.out.println("n [Nova Entrada]");
            System.out.println("d [Deletar registro]");
            System.out.println("p [Ler Registro]");
            System.out.println("q [Sair]");
            
            entrada = input.next();
            
            if(entrada.equals("n")){
                System.out.println(":::: Adicionar Contato ::::");
                System.out.println("Digite seu nome: ");
                String nome = input.next();
                System.out.println("Digite seu telefone: ");
                int tel = input.nextInt();
                Agenda entradaAg = new Agenda(nome, tel);
                pessoas.add(entradaAg);
            }
            if(entrada.equals("p")){
                System.out.println(":::: Contatos Salvos ::::");
                for(int i=0; i<pessoas.size(); i++){
                    Agenda lerAg = pessoas.get(i);
                    System.out.println("==> ID: " + lerAg.getId());
                    System.out.println("Nome: " + lerAg.getNome());
                    System.out.println("Telefone: " + lerAg.getTelefone());
                }
            }
            if(entrada.equals("d")){
                System.out.println(":::: Remover Contatos ::::");
                System.out.println("Nome do contato: ");
                String excluir = input.next();
                for(int i=0; i<pessoas.size(); i++){
                    Agenda RmvAg = pessoas.get(i);
                    if(RmvAg.getNome().equals(excluir)){
                        pessoas.remove(i);
                    }
                    
                }
            }
            
        }
    }
}
