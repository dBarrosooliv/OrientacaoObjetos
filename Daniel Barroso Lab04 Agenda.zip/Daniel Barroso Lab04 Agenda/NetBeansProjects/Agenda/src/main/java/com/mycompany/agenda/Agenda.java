/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agenda;


/**
 *
 * @author unifdoliveira
 */
public class Agenda {

    private String nome;
    private int telefone;
    private int id;
    private static int contador = 0;
    
    public Agenda(String nome, int telefone) {
        contador++;
        this.nome = nome;
        this.telefone = telefone;
        this.id = contador;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    public String getNome() {
        return nome;
    }

    public int getTelefone() {
        return telefone;
    }
    
    public int getId(){
        return id;
    }
    
}
