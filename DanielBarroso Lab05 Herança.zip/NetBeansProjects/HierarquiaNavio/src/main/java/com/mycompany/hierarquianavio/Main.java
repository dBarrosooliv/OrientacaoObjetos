/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hierarquianavio;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifdoliveira
 */
public class Main {
    
    public static void main(String[] args){

        Scanner input = new Scanner (System.in);
        //LISTAS
        ArrayList<Navio> navios = new ArrayList<>();
        ArrayList<NavioMercante> naviosM = new ArrayList<>();
        ArrayList<NavioGuerra> naviosG = new ArrayList<>();
        ArrayList<Cruzador> naviosC = new ArrayList<>();
        ArrayList<PortaAvioes> naviosP = new ArrayList<>();
        int decisao = 99;
        
        while(decisao!=0){
            
            System.out.println("::: HIERARQUIA NAVIOS :::");
            System.out.println("1. Informar Navio");
            System.out.println(">2 Exibir Info Geral");
            System.out.println("3. Informar Navio Mercante");
            System.out.println(">4. Carregar Navio Mercante");
            System.out.println("5. Informar Navio de Guerra");
            System.out.println(">6. ExibirArmas");
            System.out.println("7. Informar Cruzador");
            System.out.println(">8. Poder do Cruzador");
            System.out.println("9. Informar Porta Avioes");
            System.out.println(">10. Poder do Porta Avioes");
            System.out.println("0. Fechar");
            
            decisao = input.nextInt();
            if(decisao == 1){
                System.out.println("Informe o nome do Navio: ");
                String Nnome = input.next();
                System.out.println("Informe o numero de tripulantes");
                int nmrTripulantes = input.nextInt();
                Navio n = new Navio(nmrTripulantes,Nnome);
                navios.add(n);
            }
            else if (decisao == 2){
                for(Navio n: navios){
                    n.exibirInfoGeral();
                }
            }
            else if(decisao == 3){
                System.out.println("Informe o nome do Navio: ");
                String Nnome = input.next();
                System.out.println("Informe o numero de tripulantes");
                int nmrTripulantes = input.nextInt();
                System.out.println("Informe a capacidade de carga: ");
                double capacidade = input.nextDouble();
                System.out.println("Informe a quantidade de carga: ");
                double carga = input.nextDouble();
                
                NavioMercante n = new NavioMercante(capacidade, carga, nmrTripulantes,Nnome);
                naviosM.add(n);
            }
            else if (decisao == 4){
                for(NavioMercante n: naviosM){
                    n.carregamento();
                }
            }
            else if(decisao == 5){
                System.out.println("Informe o nome do Navio: ");
                String Nnome = input.next();
                System.out.println("Informe o numero de tripulantes");
                int nmrTripulantes = input.nextInt();
                System.out.println("Informe a blindagem: ");
                double blindagem = input.nextDouble();
                System.out.println("Informe o ataque: ");
                double ataque = input.nextDouble();
                
                NavioGuerra n = new NavioGuerra(blindagem, ataque, nmrTripulantes,Nnome);
                naviosG.add(n);
            }
            else if (decisao == 6){
                for(NavioGuerra n: naviosG){
                    n.exibirArmas();
                }
            }
            else if(decisao == 7){
                System.out.println("Informe o nome do Navio: ");
                String Nnome = input.next();
                System.out.println("Informe o numero de tripulantes");
                int nmrTripulantes = input.nextInt();
                System.out.println("Informe o numero de canhoes: ");
                double canhoes = input.nextDouble();
                System.out.println("Informe a blindagem: ");
                double blindagem = input.nextDouble();
                System.out.println("Informe o ataque: ");
                double ataque = input.nextDouble();
                
                Cruzador n = new Cruzador(canhoes, blindagem, ataque, nmrTripulantes,Nnome);
                naviosC.add(n);
            }
            else if (decisao == 8){
                for(Cruzador n: naviosC){
                    n.poderFogo();
                }
            }
            else if(decisao == 9){
                System.out.println("Informe o nome do Navio: ");
                String Nnome = input.next();
                System.out.println("Informe o numero de tripulantes");
                int nmrTripulantes = input.nextInt();
                System.out.println("Informe o numero de avioes: ");
                double avioes = input.nextDouble();
                System.out.println("Informe a blindagem: ");
                double blindagem = input.nextDouble();
                System.out.println("Informe o ataque: ");
                double ataque = input.nextDouble();
                
                PortaAvioes n = new PortaAvioes(avioes, blindagem, ataque, nmrTripulantes,Nnome);
                naviosP.add(n);
            }
            else if (decisao == 10){
                for(PortaAvioes n: naviosP){
                    n.poderFogo();
                }
            }
            
        }
    }
    
}
