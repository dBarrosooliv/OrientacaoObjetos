/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hierarquianavio;

/**
 *
 * @author unifdoliveira
 */
public class NavioGuerra extends Navio{
    
    protected double blindagem;
    protected double ataque;

    public NavioGuerra(double blindagem, double ataque, int numTripulantes, String nomeNavio) {
        super(numTripulantes, nomeNavio);
        this.blindagem = blindagem;
        this.ataque = ataque;
    }
    
    public void poderFogo(){
        System.out.println("Poder de Fogo: " +ataque);
    }
    
    public void exibirArmas (){
        System.out.println("==> Nome do Navio: " + nomeNavio);
        System.out.println("Capacidade de Tripulantes: " + numTripulantes);
        System.out.println("Blindagem: " + blindagem);
        poderFogo();
    }
     
}
