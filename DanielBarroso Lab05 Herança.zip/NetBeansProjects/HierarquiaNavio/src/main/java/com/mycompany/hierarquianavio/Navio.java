/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hierarquianavio;

/**
 *
 * @author unifdoliveira
 */
public class Navio {
    
    protected int numTripulantes;
    protected String nomeNavio;

    public Navio(int numTripulantes, String nomeNavio) {
        this.numTripulantes = numTripulantes;
        this.nomeNavio = nomeNavio;
    }
    
    public void exibirInfoGeral(){
        System.out.println("==> Nome do Navio: " + nomeNavio);
        System.out.println("Capacidade de Tripulantes: " + numTripulantes);
    }
    
}


