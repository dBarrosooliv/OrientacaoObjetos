/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hierarquianavio;

/**
 *
 * @author unifdoliveira
 */
public class PortaAvioes extends NavioGuerra {
    
    protected double numAvioes;

    public PortaAvioes(double numAvioes, double blindagem, double ataque, int numTripulantes, String nomeNavio) {
        super(blindagem, ataque, numTripulantes, nomeNavio);
        this.numAvioes = numAvioes;
    }
    
    @Override
    public void poderFogo(){
        System.out.println("Poder de Fogo: " + ataque*(numAvioes*numAvioes));
    }
}
