/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exlogin;

/**
 *
 * @author unifdoliveira
 */
public class Pessoa {
    private String nome;
    private String sobrenome;
    private String cpf;
    private int idade;

    public Pessoa(String nome, String sobrenome, String cpf, int idade) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        if(cpf.contains(".") && cpf.contains("-")){
            throw new verifica("> NÂO DIGITAR PONTO NO CPF NEM HIFEN");
        }
        else if(cpf.contains("-")){
            throw new verifica("> NÂO DIGITAR HIFEN NO CPF");  
        }
        else if(cpf.contains(".")){
            throw new verifica("> NÂO DIGITAR PONTO NO CPF");
        }
        else{
        this.cpf = cpf;
        }
        this.idade = idade;
    }
}
