/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exlogin;

import java.util.Scanner;

/**
 *
 * @author unifdoliveira
 */
public class Login {
    public static void main (String args[]){
        int ok = 1;
        Scanner input = new Scanner (System.in);
        System.out.println("::: LOGIN :::");
        while(ok!=0){
            
            System.out.println("Digite seu nome: ");
            String nome = input.next();
            System.out.println("Digite seu sobrenome: ");
            String snome = input.next();
            System.out.println("Digite usa idade: ");
            int idade = input.nextInt();
            
            try{
                System.out.println("Seu CPF: ");
                String cpf = input.next();

                Pessoa p = new Pessoa(nome, snome, cpf, idade);
                System.out.println("::: LOGIN BEM SUCEDIDO :::");
                ok=0;//ACABAaqui 
            }
            catch(verifica e){
                System.out.println("Excecao! ==>" + e);
            }
            
        }
    }
}
